<?php

namespace Twig\Extensions;

class_exists('Twig_Extensions_Extension_Date');

if (\false) {
    class DateExtension extends \Twig_Extensions_Extension_Date
    {
    }
}
