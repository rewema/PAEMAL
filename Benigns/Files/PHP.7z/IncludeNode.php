<?php

namespace Twig\Node;

class_exists('Twig_Node_Include');

if (\false) {
    class IncludeNode extends \Twig_Node_Include
    {
    }
}
